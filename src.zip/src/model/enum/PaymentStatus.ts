enum PaymentStatus {
    READY,
    IN_PROGRESS,
    DONE,
    CANCELED,
    ABORTED,
    EXPIRED,


}