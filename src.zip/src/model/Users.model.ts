interface UsersModel {
    zipcode: string;
    streetaddress: string;
    detailaddress: string;
    name: string;
    email: string;
    password: string;
    phoneNum: string;
    addressType: string;
}