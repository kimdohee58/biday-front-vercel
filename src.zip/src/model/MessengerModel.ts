import {UserModel} from "@/model/UserModel";

interface MessengerModel {
    id: number;
    user: UserModel;
}