export interface PaymentEasyPayModel {
    provider: string;
    amount: number;
    discountAmount: number;
}