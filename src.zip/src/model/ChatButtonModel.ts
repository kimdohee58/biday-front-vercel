export interface ChatButtonModel {
    id: number;
    buttonName: string;
    buttonLink: number;
    buttonImg: string;
    buttonDescription: string;
}