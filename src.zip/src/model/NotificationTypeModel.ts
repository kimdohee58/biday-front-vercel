export interface NotificationTypeModel {
    id: number;
    name: string;
    createdAt: Date;
    updatedAt: Date;
}