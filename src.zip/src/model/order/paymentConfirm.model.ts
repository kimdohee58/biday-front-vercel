export interface PaymentConfirmModel {
    awardId: number;
    paymentKey: string;
    amount: number;
    orderId: string;
}