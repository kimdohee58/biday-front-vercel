export interface PaymentFailureModel {
    code: string;
    message: string;
}