import {Spinner} from "@/shared/Spinner/Spinner";

export default function Loading() {
    return <Spinner/>
};