// 개발 환경에서의 prisma 중복생성 방지 코드
import { PrismaClient } from "@prisma/client";

declare global {
    var prisma: PrismaClient | undefined;
}

const client = globalThis.prisma || new PrismaClient();
if (process.env.NEXT_PUBLIC_MODE !== "production") globalThis.prisma = client;

export default client;