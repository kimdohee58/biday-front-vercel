export default function ProductListCard() {
    return (
        <div>
            <h1>ProductListCard</h1>
        </div>
    )
}