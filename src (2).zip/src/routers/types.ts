import type { Route as NextRouter } from "next";

export type Route = NextRouter;
export type PathName = Route;

