import {WishModel} from "@/model/product/wish.model";
import {ProductModel} from "@/model/product/product.model";
import {UserModel} from "@/model/user/user.model";

const url = `${process.env.NEXT_PUBLIC_API_SERVER_URL}/api/wish`

export async function toggleWish(wish: WishModel, user: UserModel, product: ProductModel,): Promise<any | { status: number }> {
    try {
        const param = new URLSearchParams({
            "userId": (user.id?? '').toString(),
            "productId": (product.id?? '').toString()
        })

        const response = await fetch(`${process.env.NEXT_PUBLIC_API_SERVER_URL}/wish?${param}`, {
            method: 'GET',
            headers: {
                'Content-Type' : 'application/json',
                'Authorization' : ""
            },
        });

        const data: any = await response.json();

        return data;

    } catch (error) {
        console.error("위시 상태 변경 중 오류 발생", error);

        return {status: 500}
    }
}

export async function selectWishList(user: UserModel) {
    try {
        const response = await fetch('${process.env.NEXT_PUBLIC_API_SERVER_URL}/wish/' + user.id, {
            method: 'GET',
            headers: {
                'Content-Type' : 'application/json',
                'Authorization' : ""
            },
        });

        const data = await response.json();

        console.log("+++++>" + JSON.stringify(data));

        return data;
    } catch (error) {
        console.error("위시 리스트 로드 중 오류 발생", error);
        return { status: 500 };
    }
}


export async function deleteWish(wish: WishModel) {
    try {

        const response = await fetch('${process.env.NEXT_PUBLIC_API_SERVER_URL}/wish/' + wish.id, {
            method: 'DELETE',
            headers: {
                'Content-Type' : 'application/json',
                'Authorization' : ""
            },
        });

        const data: any = await response;

        return data;

    } catch (error) {
        console.error("위시 리스트 삭제 중 오류 발생", error);

        return {status: 500}
    }

}