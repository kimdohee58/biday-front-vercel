export interface PaymentConfirmModel {
    awardId: number;
}