import {UserModel} from "@/model/user/user.model";

interface MessengerModel {
    id: number;
    user: UserModel;
}