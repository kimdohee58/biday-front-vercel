//src/components/OrderList.tsx
const OrderList = () => {
    // 실제로는 API로부터 데이터를 가져와 map을 사용하여 렌더링한다.
    const orders = [

    ];


    return(
        <div className="space-y-6">
            {/*여러 주문 내역을 렌더링*/}


            {/*실제로는 데이터를 map을 통해 렌더링 하라고 함. */}
        </div>
    )
}

export default OrderList;